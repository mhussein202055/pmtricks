<?php

namespace Illuminate\Queue;

use RuntimeException;

class MaxAttemptsExceededException extends RuntimeException
{
    //
}
